﻿<?xml version='1.0' encoding='UTF-8'?>
<Project Type="Project" LVVersion="24008000">
	<Property Name="NI.LV.All.SaveVersion" Type="Str">24.0</Property>
	<Property Name="NI.LV.All.SourceOnly" Type="Bool">true</Property>
	<Item Name="My Computer" Type="My Computer">
		<Property Name="NI.SortType" Type="Int">3</Property>
		<Property Name="server.app.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="server.control.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="server.tcp.enabled" Type="Bool">false</Property>
		<Property Name="server.tcp.port" Type="Int">0</Property>
		<Property Name="server.tcp.serviceName" Type="Str">My Computer/VI Server</Property>
		<Property Name="server.tcp.serviceName.default" Type="Str">My Computer/VI Server</Property>
		<Property Name="server.vi.callsEnabled" Type="Bool">true</Property>
		<Property Name="server.vi.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="specify.custom.address" Type="Bool">false</Property>
		<Item Name="ActiveX Excel.vi" Type="VI" URL="../ActiveX Excel Folder/XYZ Gantry/ActiveX Excel.vi"/>
		<Item Name="ActualX_FGV.vi" Type="VI" URL="../ActualX_FGV.vi"/>
		<Item Name="ActualY_FGV.vi" Type="VI" URL="../ActualY_FGV.vi"/>
		<Item Name="ActualZ_FGV.vi" Type="VI" URL="../ActualZ_FGV.vi"/>
		<Item Name="Calculate Array Positions.vi" Type="VI" URL="../Calculate Array Positions.vi"/>
		<Item Name="Calibrate Z.vi" Type="VI" URL="../Calibrate Z.vi"/>
		<Item Name="Check HTTP Connection.vi" Type="VI" URL="../Check HTTP Connection.vi"/>
		<Item Name="Create Folder if DNE.vi" Type="VI" URL="../Create Folder if DNE.vi"/>
		<Item Name="Data_FGV.vi" Type="VI" URL="../Data_FGV.vi"/>
		<Item Name="Emulate VISA.vi" Type="VI" URL="../Emulate VISA.vi"/>
		<Item Name="FGV_States.ctl" Type="VI" URL="../ActiveX Excel Folder/XYZ Gantry v2/FGV_States.ctl"/>
		<Item Name="Force ECal.vi" Type="VI" URL="../Force ECal.vi"/>
		<Item Name="Gantry.ico" Type="Document" URL="../Gantry.ico"/>
		<Item Name="GantryRTM.rtm" Type="Document" URL="../../XYZ Gantry/GantryRTM.rtm"/>
		<Item Name="GantryRTM.rtm" Type="Document" URL="../GantryRTM.rtm"/>
		<Item Name="StartMovement_FGV.vi" Type="VI" URL="../StartMovement_FGV.vi"/>
		<Item Name="GraphData_FGV.vi" Type="VI" URL="../ActiveX Excel Folder/XYZ Gantry v2/GraphData_FGV.vi"/>
		<Item Name="GraphPosition_FGV.vi" Type="VI" URL="../ActiveX Excel Folder/XYZ Gantry v2/GraphPosition_FGV.vi"/>
		<Item Name="HTTP Connected_FGV.vi" Type="VI" URL="../HTTP Connected_FGV.vi"/>
		<Item Name="HTTP_FGV.vi" Type="VI" URL="../HTTP_FGV.vi"/>
		<Item Name="Initialize.vi" Type="VI" URL="../Initialize.vi"/>
		<Item Name="ManualControl_FGV.vi" Type="VI" URL="../ManualControl_FGV.vi"/>
		<Item Name="ManualMap_FGV.vi" Type="VI" URL="../ManualMap_FGV.vi"/>
		<Item Name="Message.ctl" Type="VI" URL="../Message.ctl"/>
		<Item Name="Open Communication.vi" Type="VI" URL="../Open Communication.vi"/>
		<Item Name="ReadAdminFile.vi" Type="VI" URL="../ActiveX Excel Folder/XYZ Gantry/ReadAdminFile.vi"/>
		<Item Name="Return to Zero.vi" Type="VI" URL="../Return to Zero.vi"/>
		<Item Name="Run Gantry.vi" Type="VI" URL="../Run Gantry.vi"/>
		<Item Name="States.ctl" Type="VI" URL="../ActiveX Excel Folder/XYZ Gantry v2/States.ctl"/>
		<Item Name="States_FGV.vi" Type="VI" URL="../ActiveX Excel Folder/XYZ Gantry v2/States_FGV.vi"/>
		<Item Name="Stop_FGV.vi" Type="VI" URL="../Stop_FGV.vi"/>
		<Item Name="VISA_FGV.vi" Type="VI" URL="../VISA_FGV.vi"/>
		<Item Name="X_Array FGV.vi" Type="VI" URL="../X_Array FGV.vi"/>
		<Item Name="XYZ Gantry v2.vi" Type="VI" URL="../XYZ Gantry v2.vi"/>
		<Item Name="XYZ Gantry.vi" Type="VI" URL="../../XYZ Gantry/XYZ Gantry.vi"/>
		<Item Name="Y_Array FGV.vi" Type="VI" URL="../Y_Array FGV.vi"/>
		<Item Name="Z Calibration_FGV.vi" Type="VI" URL="../Z Calibration_FGV.vi"/>
		<Item Name="Dependencies" Type="Dependencies">
			<Item Name="vi.lib" Type="Folder">
				<Item Name="VISA Configure Serial Port" Type="VI" URL="/&lt;vilib&gt;/Instr/_visa.llb/VISA Configure Serial Port"/>
				<Item Name="VISA Configure Serial Port (Instr).vi" Type="VI" URL="/&lt;vilib&gt;/Instr/_visa.llb/VISA Configure Serial Port (Instr).vi"/>
				<Item Name="VISA Configure Serial Port (Serial Instr).vi" Type="VI" URL="/&lt;vilib&gt;/Instr/_visa.llb/VISA Configure Serial Port (Serial Instr).vi"/>
				<Item Name="LabVIEWHTTPClient.lvlib" Type="Library" URL="/&lt;vilib&gt;/httpClient/LabVIEWHTTPClient.lvlib"/>
				<Item Name="Check if File or Folder Exists.vi" Type="VI" URL="/&lt;vilib&gt;/Utility/libraryn.llb/Check if File or Folder Exists.vi"/>
				<Item Name="NI_FileType.lvlib" Type="Library" URL="/&lt;vilib&gt;/Utility/lvfile.llb/NI_FileType.lvlib"/>
				<Item Name="Error Cluster From Error Code.vi" Type="VI" URL="/&lt;vilib&gt;/Utility/error.llb/Error Cluster From Error Code.vi"/>
				<Item Name="NI_PackedLibraryUtility.lvlib" Type="Library" URL="/&lt;vilib&gt;/Utility/LVLibp/NI_PackedLibraryUtility.lvlib"/>
				<Item Name="Path To Command Line String.vi" Type="VI" URL="/&lt;vilib&gt;/AdvancedString/Path To Command Line String.vi"/>
				<Item Name="PathToUNIXPathString.vi" Type="VI" URL="/&lt;vilib&gt;/Platform/CFURL.llb/PathToUNIXPathString.vi"/>
				<Item Name="subTimeDelay.vi" Type="VI" URL="/&lt;vilib&gt;/express/express execution control/TimeDelayBlock.llb/subTimeDelay.vi"/>
				<Item Name="Stall Data Flow.vim" Type="VI" URL="/&lt;vilib&gt;/Utility/Stall Data Flow.vim"/>
				<Item Name="Read Delimited Spreadsheet.vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Read Delimited Spreadsheet.vi"/>
				<Item Name="Read Delimited Spreadsheet (DBL).vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Read Delimited Spreadsheet (DBL).vi"/>
				<Item Name="Read Lines From File (with error IO).vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Read Lines From File (with error IO).vi"/>
				<Item Name="Open File+.vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Open File+.vi"/>
				<Item Name="Read File+ (string).vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Read File+ (string).vi"/>
				<Item Name="compatReadText.vi" Type="VI" URL="/&lt;vilib&gt;/_oldvers/_oldvers.llb/compatReadText.vi"/>
				<Item Name="Close File+.vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Close File+.vi"/>
				<Item Name="Find First Error.vi" Type="VI" URL="/&lt;vilib&gt;/Utility/error.llb/Find First Error.vi"/>
				<Item Name="Read Delimited Spreadsheet (I64).vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Read Delimited Spreadsheet (I64).vi"/>
				<Item Name="Read Delimited Spreadsheet (string).vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Read Delimited Spreadsheet (string).vi"/>
				<Item Name="Write Delimited Spreadsheet.vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Write Delimited Spreadsheet.vi"/>
				<Item Name="Write Delimited Spreadsheet (DBL).vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Write Delimited Spreadsheet (DBL).vi"/>
				<Item Name="Write Spreadsheet String.vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Write Spreadsheet String.vi"/>
				<Item Name="Write Delimited Spreadsheet (I64).vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Write Delimited Spreadsheet (I64).vi"/>
				<Item Name="Write Delimited Spreadsheet (string).vi" Type="VI" URL="/&lt;vilib&gt;/Utility/file.llb/Write Delimited Spreadsheet (string).vi"/>
				<Item Name="Draw Rectangle.vi" Type="VI" URL="/&lt;vilib&gt;/picture/picture.llb/Draw Rectangle.vi"/>
				<Item Name="Set Pen State.vi" Type="VI" URL="/&lt;vilib&gt;/picture/picture.llb/Set Pen State.vi"/>
				<Item Name="Write PNG File.vi" Type="VI" URL="/&lt;vilib&gt;/picture/png.llb/Write PNG File.vi"/>
				<Item Name="imagedata.ctl" Type="VI" URL="/&lt;vilib&gt;/picture/picture.llb/imagedata.ctl"/>
				<Item Name="Check Data Size.vi" Type="VI" URL="/&lt;vilib&gt;/picture/jpeg.llb/Check Data Size.vi"/>
				<Item Name="Check Color Table Size.vi" Type="VI" URL="/&lt;vilib&gt;/picture/jpeg.llb/Check Color Table Size.vi"/>
				<Item Name="Check Path.vi" Type="VI" URL="/&lt;vilib&gt;/picture/jpeg.llb/Check Path.vi"/>
				<Item Name="Directory of Top Level VI.vi" Type="VI" URL="/&lt;vilib&gt;/picture/jpeg.llb/Directory of Top Level VI.vi"/>
				<Item Name="Check File Permissions.vi" Type="VI" URL="/&lt;vilib&gt;/picture/jpeg.llb/Check File Permissions.vi"/>
				<Item Name="Picture to Pixmap.vi" Type="VI" URL="/&lt;vilib&gt;/picture/pictutil.llb/Picture to Pixmap.vi"/>
				<Item Name="Draw Text at Point.vi" Type="VI" URL="/&lt;vilib&gt;/picture/picture.llb/Draw Text at Point.vi"/>
				<Item Name="Get Text Rect.vi" Type="VI" URL="/&lt;vilib&gt;/picture/picture.llb/Get Text Rect.vi"/>
				<Item Name="Draw Text in Rect.vi" Type="VI" URL="/&lt;vilib&gt;/picture/picture.llb/Draw Text in Rect.vi"/>
				<Item Name="PCT Pad String.vi" Type="VI" URL="/&lt;vilib&gt;/picture/picture.llb/PCT Pad String.vi"/>
			</Item>
			<Item Name="ReadAdminFile.vi" Type="VI" URL="../../XYZ Gantry/ReadAdminFile.vi"/>
			<Item Name="GraphData_FGV.vi" Type="VI" URL="../GraphData_FGV.vi"/>
			<Item Name="FGV_States.ctl" Type="VI" URL="../FGV_States.ctl"/>
			<Item Name="GraphPosition_FGV.vi" Type="VI" URL="../GraphPosition_FGV.vi"/>
			<Item Name="States_FGV.vi" Type="VI" URL="../States_FGV.vi"/>
			<Item Name="States.ctl" Type="VI" URL="../States.ctl"/>
			<Item Name="TriggerXRF.vi" Type="VI" URL="../../XYZ Gantry/TriggerXRF.vi"/>
			<Item Name="XY to Array.vi" Type="VI" URL="../../XYZ Gantry/XY to Array.vi"/>
			<Item Name="CoatingsInDB.vi" Type="VI" URL="../../XYZ Gantry/CoatingsInDB.vi"/>
			<Item Name="Admin.vi" Type="VI" URL="../../XYZ Gantry/Admin.vi"/>
			<Item Name="GantryZero.vi" Type="VI" URL="../../XYZ Gantry/GantryZero.vi"/>
			<Item Name="SaveSerialPort.vi" Type="VI" URL="../../XYZ Gantry/SaveSerialPort.vi"/>
			<Item Name="ManualMode.vi" Type="VI" URL="../../XYZ Gantry/ManualMode.vi"/>
			<Item Name="Manual Gantry Control.vi" Type="VI" URL="../../XYZ Gantry/Manual Gantry Control.vi"/>
			<Item Name="OrganizeDataForExcel.vi" Type="VI" URL="../../XYZ Gantry/OrganizeDataForExcel.vi"/>
			<Item Name="GraphicalTool.vi" Type="VI" URL="../../XYZ Gantry/GraphicalTool.vi"/>
			<Item Name="ReadOffset.vi" Type="VI" URL="../../XYZ Gantry/ReadOffset.vi"/>
		</Item>
		<Item Name="Build Specifications" Type="Build">
			<Item Name="XYZ Gantry v2" Type="EXE">
				<Property Name="App_copyErrors" Type="Bool">true</Property>
				<Property Name="App_INI_aliasGUID" Type="Str">{60FA5ECB-C7A1-451D-8582-D2DF5C2B63CB}</Property>
				<Property Name="App_INI_GUID" Type="Str">{C1BD37B1-2AF1-40F1-841F-207D5508D8EF}</Property>
				<Property Name="App_serverConfig.httpPort" Type="Int">8002</Property>
				<Property Name="App_serverType" Type="Int">0</Property>
				<Property Name="Bld_autoIncrement" Type="Bool">true</Property>
				<Property Name="Bld_buildCacheID" Type="Str">{1CF83EB7-1A44-40B0-A2D7-A7435C3CF6CF}</Property>
				<Property Name="Bld_buildSpecName" Type="Str">XYZ Gantry v2</Property>
				<Property Name="Bld_excludeInlineSubVIs" Type="Bool">true</Property>
				<Property Name="Bld_excludeLibraryItems" Type="Bool">true</Property>
				<Property Name="Bld_excludePolymorphicVIs" Type="Bool">true</Property>
				<Property Name="Bld_localDestDir" Type="Path">../builds/NI_AB_PROJECTNAME/XYZ Gantry v2</Property>
				<Property Name="Bld_localDestDirType" Type="Str">relativeToCommon</Property>
				<Property Name="Bld_modifyLibraryFile" Type="Bool">true</Property>
				<Property Name="Bld_previewCacheID" Type="Str">{1166D5BF-0D88-41D3-878D-AE9D2CBC1F89}</Property>
				<Property Name="Bld_version.build" Type="Int">6</Property>
				<Property Name="Bld_version.major" Type="Int">1</Property>
				<Property Name="Destination[0].destName" Type="Str">XYZ Gantry v2.0.1.exe</Property>
				<Property Name="Destination[0].path" Type="Path">../builds/NI_AB_PROJECTNAME/XYZ Gantry v2/XYZ Gantry v2.0.1.exe</Property>
				<Property Name="Destination[0].preserveHierarchy" Type="Bool">true</Property>
				<Property Name="Destination[0].type" Type="Str">App</Property>
				<Property Name="Destination[1].destName" Type="Str">Support Directory</Property>
				<Property Name="Destination[1].path" Type="Path">../builds/NI_AB_PROJECTNAME/XYZ Gantry v2/data</Property>
				<Property Name="DestinationCount" Type="Int">2</Property>
				<Property Name="Exe_iconItemID" Type="Ref">/My Computer/Gantry.ico</Property>
				<Property Name="Source[0].itemID" Type="Str">{7848B3A0-E928-41CB-BCB4-7971E512E7FB}</Property>
				<Property Name="Source[0].type" Type="Str">Container</Property>
				<Property Name="Source[1].destinationIndex" Type="Int">0</Property>
				<Property Name="Source[1].itemID" Type="Ref">/My Computer/XYZ Gantry v2.vi</Property>
				<Property Name="Source[1].sourceInclusion" Type="Str">TopLevel</Property>
				<Property Name="Source[1].type" Type="Str">VI</Property>
				<Property Name="SourceCount" Type="Int">2</Property>
				<Property Name="TgtF_fileDescription" Type="Str">XYZ Gantry v2</Property>
				<Property Name="TgtF_internalName" Type="Str">XYZ Gantry v2</Property>
				<Property Name="TgtF_productName" Type="Str">XYZ Gantry v2</Property>
				<Property Name="TgtF_targetfileGUID" Type="Str">{E056EC86-48CE-434B-8CCB-FB315C54FC33}</Property>
				<Property Name="TgtF_targetfileName" Type="Str">XYZ Gantry v2.0.1.exe</Property>
				<Property Name="TgtF_versionIndependent" Type="Bool">true</Property>
			</Item>
		</Item>
	</Item>
</Project>
